let sketch = require("sketch");
let document = sketch.getSelectedDocument();
let selection = document.selectedLayers.layers;
let count = 0;

function resetAbleLayerNames(context) {
  resetLayerNames(false, confirmReset);
}

function resetAbleSpacingNames(context) {
  resetLayerNames(true, confirmReset);
}

function processLayer(layer, spacing) {
  if (layer.type === "Artboard" || layer.type === "Group" || layer.type ==="SymbolMaster") {
    layer.layers.forEach((nestedLayer) => {
      processLayer(nestedLayer, spacing);
    });
  } else if (spacing === true) {
    if (
      layer.type === "SymbolInstance" &&
      layer.master.getLibrary().name.includes("Able") &&
      layer.master.name.includes("spacing")
    ) {
      if (layer.name !== layer.master.name) {
        layer.name = layer.master.name;
        count++;
      }
    }
  } else {
    if (
      layer.type === "SymbolInstance" &&
      layer.master.getLibrary().name.includes("Able")
    ) {
      if (layer.name !== layer.master.name) {
        layer.name = layer.master.name;
        count++;
      }
    }
  }
}

function resetLayerNames(spacing, callback) {
  if (selection.length) {
    selection.forEach((layer) => {
      processLayer(layer, spacing);
    });

    if (count) {
      callback();
    }
  }
}

function confirmReset() {
  let message;
  if (count > 1) {
    message = count.toString().concat(" Able layer names reset");
  } else if (count === 1) {
    message = "1 Able layer name reset";
  } else {
    message = "No Able layer names to reset";
  }
  sketch.UI.message(message);
}
