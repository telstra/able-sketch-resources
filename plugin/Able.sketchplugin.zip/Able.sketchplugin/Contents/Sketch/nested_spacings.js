let sketch = require("sketch");
let document = sketch.getSelectedDocument();
let { Page } = sketch;
let invisibleSpaceId = null;
let count = 0;

function toggleNestedSpacing(context) {
  toggleSpacing(confirmToggle);
}

function createInvisibleSpace() {
  // Store the current active page
  let currentPage = document.selectedPage;

  // Get the Symbols page or create one if it doesn't exist
  let symbolsPage = document.pages.find((page) => page.name === "Symbols");
  if (!symbolsPage) {
    const nativeSymbolsPage = MSDocument.currentDocument().addBlankPage();
    nativeSymbolsPage.setName("Symbols");
    symbolsPage = sketch.fromNative(nativeSymbolsPage);
  }

  let SymbolMaster = sketch.SymbolMaster;
  let Rectangle = sketch.Rectangle;

  let invisibleSpace = new SymbolMaster({
    name: "Invisible Space",
    frame: new Rectangle(0, 0, 100, 100),
    parent: symbolsPage, // Set parent to the Symbols page
  });

  // Set the active page back to the original page
  document.selectedPage = currentPage;

  return invisibleSpace.symbolId;
}

function overrideSpacingSymbol(selection) {
  selection.forEach((layer) => {
    // If the layer is an Artboard or Group
    if (layer.type === "Artboard" || layer.type === "Group") {
      overrideSpacingSymbol(layer.layers);
    }

    // If the layer is a Symbol Instance
    else if (layer.type === "SymbolInstance") {
      let overrides = layer.overrides;

      overrides.forEach((override) => {
        if (
          override.editable &&
          override.symbolOverride &&
          override.affectedLayer.name.includes("spacing") &&
          override.value
        ) {
          if (override.value === override.affectedLayer.symbolId) {
            override.value = invisibleSpaceId;
            count++;
          } else {
            override.value = override.affectedLayer.symbolId;
            count++;
          }
        }
      });
    }
  });
}

function toggleSpacing(callback) {
  let selection = document.selectedLayers.layers;

  document.getSymbols().forEach((symbol) => {
    if (symbol.name === "Invisible Space") {
      invisibleSpaceId = symbol.symbolId;
      console.log("Invisible Space exists");
    }
  });

  // If it doesn't exist, create the symbol and get its ID
  if (!invisibleSpaceId) {
    invisibleSpaceId = createInvisibleSpace();
    console.log("Invisible Space does not exist");
  }

  // Conceal or reveal the nested spacing
  if (selection.length) {
    overrideSpacingSymbol(selection);
  }

  if (count) {
    callback();
  }
}

function confirmToggle() {
  let message;
  if (count > 1) {
    message = count.toString().concat(" nested spacings toggled");
  } else if (count === 1) {
    message = "1 nested spacing toggled";
  } else {
    message = "No nested spacings to toggle";
  }
  sketch.UI.message(message);
}
